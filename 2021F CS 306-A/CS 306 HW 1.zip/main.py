encodedStrs = ["2d0a0612061b0944000d161f0c1746430c0f0952181b004c1311080b4e07494852",
"200a054626550d051a48170e041d011a001b470204061309020005164e15484f44",
"3818101500180b441b06004b11104c064f1e0616411d064c161b1b04071d460101",
"200e0c4618104e071506450604124443091b09520e125522081f061c4e1d4e5601",
"304f1d091f104e0a1b48161f101d440d1b4e04130f5407090010491b061a520101",
"2d0714124f020111180c450900595016061a02520419170d1306081c1d1a4f4601",
"351a160d061917443b3c354b0c0a01130a1c01170200191541070c0c1b01440101",
"3d0611081b55200d1f07164b161858431b0602000454020d1254084f0d12554249",
"340e0c040a550c1100482c4b0110450d1b4e1713185414181511071b071c4f0101",
"2e0a5515071a1b081048170e04154d1a4f020e0115111b4c151b492107184e5201",
"370e1d4618104e05060d450f0a104f044f080e1c04540205151c061a1a5349484c"]

validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ. "

from hashlib import sha256

def convertToHexArray(str):
    result = []
    for x in range(0, len(str), 2):
        result += [bytes.fromhex(str[x:x+2]).decode("ASCII")]
    return result

def XORAllOthers(encodedStrs, target):
    result = []
    for x in range(len(encodedStrs)):
        targetStr = encodedStrs[target]
        if x == target: continue
        result += [list(map(lambda a, b: ord(a)^ord(b), encodedStrs[x], targetStr))]
    return result

def filterChar(XORstrs, char):
    result = [True]*len(XORstrs[0])
    for string in XORstrs:
        for index,c in enumerate(string):
            xorresult = ord(char) ^ c
            if(chr(xorresult) not in validChars):
                result[index] = False
    return result

def bruteForce(hexStrs, ind):
    XORs = XORAllOthers(hexStrs, ind)
    result = [""] * len(hexStrs[ind])
    for ch in validChars:
        valids = filterChar(XORs, ch)
        for index, entry in enumerate(valids):
            if entry:
                result[index] += ch
    return result

def decode(strs, key):
    result = []
    for string in strs:
        result += ["".join(list(map(lambda x, y: chr(ord(x) ^ y), string, key)))]
    return result
foundKey = [121, 111, 117, 102, 111, 117, 110, 100, 116, 104, 101, 107, 101, 121, 33, 99, 111, 110, 103, 114, 97, 116, 117, 108, 97, 116, 105, 111, 110, 115, 33, 33, 33]

def rehash(n):
  hexStringKey = "".join(list(map(lambda x: hex(x)[2:], foundKey))).upper()
  print(hexStringKey)
  bytesKey = bytes.fromhex(hexStringKey)
  current = bytesKey
  for x in range(n):
    shaObj = sha256()
    shaObj.update(current)
    currentstr = str(shaObj.hexdigest())[2:] + "21"
    current = bytes.fromhex(currentstr)
    
  return current.hex() + "21"



def main():
    hexStrs = list(map(convertToHexArray, encodedStrs))
    key = [""] * len(hexStrs[0])

    #print(hexStrs)
    for x in range(len(hexStrs)):
        bruteResult = bruteForce(hexStrs, x)
        print(bruteResult)
        for index, entry in enumerate(bruteResult):
            if(len(entry) == 1):
                key[index] = ord(hexStrs[x][index]) ^ ord(entry[0])
            elif key[index] == "":
                print(bruteResult)
                print("value ("+ entry + ") found for brute forced candidate")
                value = input("input real character or skip with no input: ")
                if(len(value) == 1):
                    key[index] = ord(hexStrs[x][index]) ^ ord(value)

    print(key)
    print(decode(hexStrs, key))

    

#main()
print(decode(list(map(convertToHexArray, encodedStrs)), foundKey))
print("".join(map(lambda x: (bytes.fromhex(hex(x)[2:])).decode("ASCII"), foundKey)))
print(rehash(21))
