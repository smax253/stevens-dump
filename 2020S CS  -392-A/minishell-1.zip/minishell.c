/*******************************************************************************
 * Name        : minishell.c
 * Author      : Max Shi and Hamzah Nizami
 * Date        : 4/15/2020
 * Description : MiniShell written in C
 * Pledge : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <errno.h>
#include <pwd.h>
#include <limits.h>
#include <setjmp.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <wait.h>

#define BRIGHTBLUE "\x1b[34;1m"
#define DEFAULT "\x1b[0m"

sigjmp_buf jmpbuf;
sig_atomic_t child_finished = 1;

void catch_signal(int sig){
  if(child_finished == 1){
    write(STDOUT_FILENO, "\n", 1);
    siglongjmp(jmpbuf,1);
  }
}

int process_path(char * original_path){
  char *current = original_path;
  char path[PATH_MAX];
  int argc = 0;
  //loop until end
  while(*current != '\0'){
    //not space = argument
    if (*current != ' '){
      //count quotes as one argument
      if(*current == '"'){
        argc++;
        current++;
        while(*current != '"' && *current != '\0'){
          current++;
        }
        if(*current == '\0') {
          fprintf(stderr, "Error: Malformed command.\n");
          return -1;
        }
        current++;
      }
      //count everything after a space until next space as an argument
      else{
        argc++;
        while(*current != ' ' && *current != '\0'){
          current++;
        }
      }
    }else{
      current++;
    }
    //printf("%c-",*current);
  }
  if (argc > 2){
    fprintf(stderr,"Error: Too many arguments to cd.\n");
    return -1;
  }
  //extract base path
  if(argc == 2){
    current = original_path+3;
    while(*current == ' ') current++;   //trim infix whitespace
    strcpy(path, current);
    strcpy(original_path, path);

  }
  //check if on our way home
  if (argc == 1 || strncmp(original_path, "~", 2)==0){
    uid_t user = getuid();
    struct passwd *pass = getpwuid(user);
    if(pass == NULL){
      fprintf(stderr,"Error: Cannot get passwd entry. %s.\n", strerror(errno));
      return -1;
    }
    char * home_dir = pass->pw_dir;
    //ooooo pointers
    strcpy(path, home_dir);
    if (argc == 2){
      strcpy(path+strlen(path), original_path+1);
    }
      strcpy(original_path, path);

  }else if (*original_path == '"'){
    //trim quotes if quotes used
    *(original_path + strlen(original_path)-1) = '\0';
    strcpy(path, original_path+1);
    strcpy(original_path, path);
  }
  return 0;
}

int main(int argc, char * argv[]){

  //signal handler
  struct sigaction action;
  memset(&action, 0, sizeof(struct sigaction));
  action.sa_handler = catch_signal;
  action.sa_flags = SA_RESTART;

  if(sigaction(SIGINT, &action, NULL) == -1){
    fprintf(stderr, "Error: Cannot register signal handler. %s.\n", strerror(errno));
    return EXIT_FAILURE;
  }

  //prompt
  char buf[BUFSIZ];
  memset(buf, 0, sizeof(buf));  //avoid valgrind errors???  (; ･`д･´)
  char current_dir[PATH_MAX];
  char temp[BUFSIZ];
  memset(temp, 0, sizeof(buf));
  sigsetjmp(jmpbuf, 1);   //jump here on interrupt
  do{
    if(getcwd(current_dir, PATH_MAX)==NULL){
      fprintf(stderr, "Cannot get current working directory. %s.\n", strerror(errno));
    }
    printf("[%s%s%s]$ ", BRIGHTBLUE, current_dir, DEFAULT);
    fflush(stdout);
    ssize_t bytes_read = read(STDOUT_FILENO, buf, BUFSIZ-1);

    //get rid of leading whitespace
    size_t leading_spaces = 0;
    for(char * current = buf; *current == ' '; current++){
      leading_spaces++;
    }
    strcpy(temp, buf+leading_spaces);
    strcpy(buf, temp);
    bytes_read-=leading_spaces;

    //get rid of trailing spaces
    while(bytes_read>2 && buf[bytes_read-2]==' '){
      bytes_read--;
    }
    //set last byte to null terminating
    if (bytes_read>0){
      buf[bytes_read-1] = '\0';
    }if(bytes_read == 1){
      continue;
    }
    //exit command
    if(strncmp(buf, "exit", 5)==0){
      break;
    }
    //cd command
    else if(strncmp(buf, "cd", 2)==0 && (buf[2] == ' ' || buf[2] == '\0')){
      if (process_path(buf)==-1){
        continue;
      }
      //printf("%s\n", buf);
      if(chdir(buf)==-1){
        fprintf(stderr, "Error: Cannot change directory to '%s'. %s.\n", buf, strerror(errno));
      }
      continue;
    }
    //other commands
    else{
      child_finished = 0;
      pid_t pid;
      if((pid = fork())<0){
          fprintf(stderr, "Error: fork() failed. %s.\n", strerror(errno));
      }
      else if(pid>0){
        //parent
        int status;
        do{
          pid_t w = waitpid(pid, &status, WUNTRACED | WCONTINUED);
          if(w == -1){
            fprintf(stderr, "Error: wait() failed. %s.\n", strerror(errno));
            break;
          }
        }while(!WIFEXITED(status) && !WIFSIGNALED(status));
      }else{

        int argcount = 1; //includes NULL argument needed for execvp
        char * current = buf;
        //count number of arguments with poooointer arith
        while(*current != '\0'){
          if(*current != ' ') {
            argcount++;
            while(*current != ' ' && *current != '\0') current++;
          }
          else
            current++;
        }

        char ** arguments;
        if ((arguments = (char **) malloc(argcount*sizeof(char *)))==NULL){  // ew malloc
          fprintf(stderr, "Error: malloc() failed. %s.\n", strerror(errno));
          return EXIT_FAILURE;
        }
        current = buf;
        for(int argindex = 0; argindex<argcount-1; argindex++){
          char * argument;
          if((argument = (char *) malloc(sizeof(char)*128))==NULL){         //ewwwwww
            fprintf(stderr, "Error: malloc() failed. %s.\n", strerror(errno));
            for(int i = 0; i<argindex; i++){
              free(arguments[i]);
            }
            free(arguments);
            return EXIT_FAILURE;
          }
          char * argptr = argument;
          while(*current == ' ') current++;     //trim infix whitespace
          while(*current != '\0' && *current != ' '){
            *argptr = *current;
            argptr++;
            current++;
          }
          while(*current==' ') current++;
          *argptr = '\0';
          arguments[argindex] = argument;
        }
        arguments[argcount-1] = NULL;     //set NULL argument
        //exec command
        if(execvp(arguments[0], arguments) == -1){
          fprintf(stderr, "Error: exec() failed. %s.\n", strerror(errno));
          //free mallocs
          for(int i = 0; i<argcount; i++){
            free(arguments[i]);
          }
          free(arguments);
          child_finished = 1;
          return EXIT_FAILURE;
        }
        //free mallocs
        for(int i = 0; i<argcount; i++){
          free(arguments[i]);
        }
        free(arguments);
        child_finished = 1;
        return EXIT_SUCCESS;
      }
    }
  }while(true);

  return EXIT_SUCCESS;
}
