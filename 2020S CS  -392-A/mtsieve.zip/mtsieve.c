/*******************************************************************************
 * Name        : mtsieve.c
 * Author      : Max Shi and Hamzah Nizami
 * Date        : 4/24/2020
 * Description : Multithreaded prime sieve of erastothenes
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>
#include <sys/sysinfo.h>
#include <math.h>

typedef struct arg_struct {
    int start;
    int end;
} thread_args;

int total_count = 0;
pthread_mutex_t lock;


void *sieve(void *ptr){
    thread_args *thread = (thread_args *)ptr;
    int sqrt_end = (int)sqrt(thread->end);
    char *low_primes = (char*)malloc((sqrt_end+1) * sizeof(char));
    memset(low_primes, 't', sqrt_end+1);

    for(int i = 2; i <= sqrt_end; i++){
        if(low_primes[i]){
            for(int j = i*i; j <= sqrt_end; j += i ){
                low_primes[j] = '\0';
            }
        }
    }

    int high_limit = thread->end - thread->start;
    char *high_primes = (char*)malloc((high_limit + 1) * sizeof(char));
    memset(high_primes, 't', high_limit+1);

    for(int p = 2; p <= sqrt_end; p++){
      if(low_primes[p]){
       double i = ceil((double)thread->start/p) * p - thread->start;
       if(thread->start <= p){
           i = i + p;
       }
       for(int j = i; j <=high_limit; j+= p){
           high_primes[j] = '\0';
       }
     }
    }

    // for(int i = 0; i < high_limit; i++){
    //     if(high_primes[i]){
    //         printf("%d\n", i + thread->start);
    //     }
    // }

    int local_count = 0;
    for(int i = 0; i <= high_limit; i++){
        if(high_primes[i]){
            int prime = i + thread->start;
            for(int j = prime, counter = 0; j > 0; j /=10){
                if(j % 10 == 3){
                    counter++;
                }
                if (counter>=2){
                  local_count++;
                  break;
                }
            }
        }
    }

    int retval;
    if ((retval = pthread_mutex_lock(&lock)) != 0) {
        fprintf(stderr, "Warning: Cannot lock mutex. %s.\n",
                strerror(retval));
    }
    total_count += local_count;
    if ((retval = pthread_mutex_unlock(&lock)) != 0) {
        fprintf(stderr, "Warning: Cannot unlock mutex. %s.\n",
                strerror(retval));
    }
    free(high_primes);
    free(low_primes);
    pthread_exit(NULL);
}

int valid_num(char s[], int * value){
    long int num = strtol(s, NULL, 10); //???
    if(num > INT_MAX){
        return -1;
    }
    if(num < INT_MIN){
        *value = -1;
    } else if (num == 0){
        int check = strncmp(s, "0", 2);
        if(check != 0){
            //conversion error
            return -2;
        }
    } else{
        char * buf = (char*)malloc((strlen(s)+1) * sizeof(char));
        *value = num;
        sprintf(buf, "%d", *value);
        if(strcmp(buf, s) != 0){
            free(buf);
            return -2;
        }
        free(buf);
    }
    return 0;
}

int main(int argc, char * argv[]){
    if(argc == 1){
        fprintf(stderr, "Usage: ./mtsieve -s <starting value> -e <ending value> -t <num threads>\n");
        return EXIT_FAILURE;
    }
    //Check the validity of the flags
    int opt,starting, ending, num_threads, retval;
    int sflag = 0, eflag = 0, tflag = 0;
    while((opt = getopt(argc, argv, ":s:e:t:")) != -1){
        switch(opt){
            case 's':
                sflag++;
                //call function, check for -1: integer overflow
                if((retval = valid_num(optarg, &starting)) != 0){
                    if(retval == -1){
                        fprintf(stderr, "Error: Integer overflow for parameter '-%c'.\n", opt);
                        return EXIT_FAILURE;
                    } else if(retval == -2){
                        fprintf(stderr, "Error: Invalid input '%s' received for parameter '-%c'.\n", optarg, opt);
                        return EXIT_FAILURE;
                    }
                }
                break;
            case 'e':
                eflag++;
                if((retval = valid_num(optarg, &ending)) != 0){
                    if(retval == -1){
                        fprintf(stderr, "Error: Integer overflow for parameter '-%c'.\n", opt);
                        return EXIT_FAILURE;
                    } else if(retval == -2){
                        fprintf(stderr, "Error: Invalid input '%s' received for parameter '-%c'.\n", optarg, opt);
                        return EXIT_FAILURE;
                    }
                }
                break;
            case 't':
                tflag++;
                if((retval = valid_num(optarg, &num_threads)) != 0){
                    if(retval == -1){
                        fprintf(stderr, "Error: Integer overflow for parameter '-%c'.\n", opt);
                        return EXIT_FAILURE;
                    } else if(retval == -2){
                        fprintf(stderr, "Error: Invalid input '%s' received for parameter '-%c'.\n", optarg, opt);
                        return EXIT_FAILURE;
                    }
                }
                break;
            case '?': case ':':
                if(optopt == 'e' || optopt == 's' || optopt == 't'){
                    fprintf(stderr, "Error: Option -%c requires an argument.\n", optopt);
                } else if (isprint(optopt)) {
                    fprintf(stderr, "Error: Unknown option '-%c'.\n", optopt);
                } else {
                    fprintf(stderr, "Error: Unknown option character '\\x%x'.\n", optopt);
                }
                return EXIT_FAILURE;
        }
    }
    if(optind < argc){
        fprintf(stderr, "Error: Non-option argument '%s' supplied.\n", argv[optind]);
        return EXIT_FAILURE;
    }
    if(sflag == 0){
        fprintf(stderr, "Error: Required argument <starting value> is missing.\n");
        return EXIT_FAILURE;
    }
    if(starting < 2){
        fprintf(stderr, "Error: Starting value must be >= 2.\n");
        return EXIT_FAILURE;
    }
    if(eflag == 0){
        fprintf(stderr, "Error: Required argument <ending value> is missing.\n");
        return EXIT_FAILURE;
    }
    if(ending < 2){
        fprintf(stderr, "Error: Ending value must be >= 2.\n");
        return EXIT_FAILURE;
    }
    if(ending < starting){
        fprintf(stderr,"Error: Ending value must be >= starting value.\n");
        return EXIT_FAILURE;
    }
    if(tflag == 0){
        fprintf(stderr, "Error: Required argument <num threads> is missing.\n");
        return EXIT_FAILURE;
    }
    if(tflag < 1){
        fprintf(stderr, "Error: Number of threads cannot be less than 1.\n");
        return EXIT_FAILURE;
    }
    if(num_threads > get_nprocs() * 2){
        fprintf(stderr, "Error: Number of threads cannot exceed twice the number of processors(%d).\n", get_nprocs());
        return EXIT_FAILURE;
    }

    int prime_test = ending - starting + 1;
    if(num_threads > prime_test){
        num_threads = prime_test;
    }

    int interval = prime_test / num_threads;
    int remainder = prime_test % num_threads;

    pthread_t *threads = (pthread_t *)malloc(num_threads * sizeof(pthread_t));
    thread_args *targs = (thread_args *)malloc(num_threads * sizeof(thread_args));

    int prev = starting;
    for(int i = 0; i < num_threads; i++){ //setting up the thread args
        thread_args t;
        t.start = prev;
        if(i < remainder){
            prev += interval + 1;
        } else {
            prev += interval;
        }
        t.end = prev - 1;
        targs[i] = t;
    }

    if ((retval = pthread_mutex_init(&lock, NULL)) != 0) {
        fprintf(stderr, "Error: Cannot create mutex. %s.\n", strerror(retval));
        free(targs);
        free(threads);
        return EXIT_FAILURE;
    }

    printf("Finding all prime numbers between %d and %d.\n", starting, ending);
    if(num_threads > 1){
        printf("%d segments:\n", num_threads);
    } else {
        printf("%d segment:\n", num_threads);
    }
    for(int i = 0; i < num_threads; i++){
        printf("   [%d, %d]\n", targs[i].start, targs[i].end);
    }
    
    for (int i = 0; i < num_threads; i++) {
        if ((retval = pthread_create(&threads[i], NULL, sieve,
                           (void *)(&targs[i])))) {
            fprintf(stderr, "Error: Cannot create thread %d. %s.\n",i+1 ,
                             strerror(retval));
            for (int j = 0; j < i; j++) {
                if (pthread_join(threads[j], NULL) != 0) {
                    fprintf(stderr, "Warning: Thread %d did not join properly.\n",
                            j + 1);
                }
            }
            free(threads);
            free(targs);
            return EXIT_FAILURE;
        }
    }

    for (int i = 0; i < num_threads; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            fprintf(stderr, "Warning: Thread %d did not join properly.\n",
                    i + 1);
        }
    }

    if ((retval = pthread_mutex_destroy(&lock)) != 0) {
        fprintf(stderr, "Error: Cannot destroy mutex. %s.\n", strerror(retval));
        free(threads);
        free(targs);
        return EXIT_FAILURE;
    }

    //now to print the values:

    printf("Total primes between %d and %d with two or more '3' digits: %d\n", starting, ending, total_count);

    free(threads);
    free(targs);
    return EXIT_SUCCESS;

}
