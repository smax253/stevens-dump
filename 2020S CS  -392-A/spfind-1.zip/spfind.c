/*******************************************************************************
 * Name        : spfind.c
 * Author      : Max Shi and Hamzah Nizami
 * Date        : 3/29/2020
 * Description : Use fork and sort to sort the output of pfind using the given arguments.
 * Pledge : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <errno.h>
#include <getopt.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

void display_usage(char * arg){
  printf("Usage: %s -d <directory> -p <permissions string> [-h]\n", arg);
}

int main(int argc, char * argv[]){
  int opt;
  if(argc==1){
    display_usage(argv[0]);
    exit(EXIT_FAILURE);
  }
  while((opt = getopt(argc, argv, ":d:p:h")) != -1){//d - directory, p- perm string
      switch (opt) {
          case 'p': case 'd':
              break;
          case 'h':
              display_usage(argv[0]);
              return EXIT_SUCCESS;
          case '?':
              fprintf(stderr, "Unknown option '-%c' received.\n", optopt);
              return EXIT_FAILURE;
              break;
      }
  }
  int pfind_to_sort[2], sort_to_parent[2];
  pipe(pfind_to_sort);
  pipe(sort_to_parent);
  pid_t pid[2];
  if ((pid[0] = fork()) == 0){
    close(pfind_to_sort[0]);
    close(sort_to_parent[0]);
    close(sort_to_parent[1]);
    if (dup2(pfind_to_sort[1], STDOUT_FILENO)==-1){
        fprintf(stderr, "Error: pfind failed.\n");
        exit(EXIT_FAILURE);
    }
    argv[0] = "./pfind";
    if (execv("./pfind", argv)==-1){
        fprintf(stderr, "Error: pfind failed.\n");
        exit(EXIT_FAILURE);
    }
  }
  if((pid[1] = fork())==0){
    close(pfind_to_sort[1]);
    close(sort_to_parent[0]);
    if (dup2(pfind_to_sort[0], STDIN_FILENO)==-1){
        fprintf(stderr, "Error: sort failed.\n");
        exit(EXIT_FAILURE);
    }
    if (dup2(sort_to_parent[1], STDOUT_FILENO)==-1){
        fprintf(stderr, "Error: sort failed.\n");
        exit(EXIT_FAILURE);
    }
    if (execlp("sort", "sort", NULL)==-1){
        fprintf(stderr, "Error: sort failed.\n");
        exit(EXIT_FAILURE);
    }
  }
  close(pfind_to_sort[0]);
  close(pfind_to_sort[1]);
  close(sort_to_parent[1]);
  dup2(sort_to_parent[0], STDIN_FILENO);
  for(int i = 0; i<2;i++){
    int status;
    wait(&status);
    if (!(WIFEXITED(status)&& WEXITSTATUS(status) == EXIT_SUCCESS)) exit(EXIT_FAILURE);
  }
  char buffer[PATH_MAX+1];
  ssize_t count;
  int file_count = 0;
  while((count = read(STDIN_FILENO, buffer, sizeof(buffer)-1)) > 0){
    for(int i = 0; i<count; i++){
      if (buffer[i] == '\n') file_count++;
    }
    buffer[count] = '\0';
    printf("%s", buffer);
  }
  if (count < 0){
    perror("read()");
    exit(EXIT_FAILURE);
  }
  printf("Total matches: %d\n", file_count);
  return EXIT_SUCCESS;
}
