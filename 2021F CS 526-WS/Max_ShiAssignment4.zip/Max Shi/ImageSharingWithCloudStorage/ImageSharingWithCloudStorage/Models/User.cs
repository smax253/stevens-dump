﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImageSharingWithCloudStorage.Models
{
    //public class User
    //{
    //    [Key]
    //    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    //    public virtual int Id {get;set;}
    //    [Required]
    //    [MaxLength(20)]
    //    public virtual string Username {get;set;}
    //    public virtual bool ADA { get; set; }
    //    public virtual bool Active { get; set; }

    //    public virtual ICollection<Image> Images {get;set;}

    //    public User() {
    //        Active = true;
    //    }

    //    public User(string u, bool a)
    //    {
    //        Active = true;
    //        Username = u;
    //        ADA = a;
    //        Images = new List<Image>();
    //    }
    //}
}